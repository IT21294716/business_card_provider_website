import React from 'react';
import Navbar from './component/Navbar';
import Herosection from './component/Herosection';
import Menu from './component/Menu';
import Products from './component/Products';
import Design from './component/Design';
import Testimonials from './component/Testimonials';
import Footer from './component/Footer';


function App() {
  return (
    <div>
      <Navbar></Navbar>
      <Herosection></Herosection>
      <Menu></Menu>
      <Products></Products>
      <Design></Design>
      <Testimonials></Testimonials>
      <Footer></Footer>
    </div>

  );
};

export default App;


