import React, { useState } from 'react';

const Design = () => {
  const [formData, setFormData] = useState({
    cardType: 'classic',
    color: '',
    firstName: '',
    lastName: '',
    role: '',
    companyName: '',
    contactNumber: '',
  });

  const [errors, setErrors] = useState({
    firstName: '',
    lastName: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const validate = () => {
    let valid = true;
    let newErrors = { firstName: '', lastName: '' };

    if (!formData.firstName.trim()) {
      newErrors.firstName = 'First name is required';
      valid = false;
    }
    if (!formData.lastName.trim()) {
      newErrors.lastName = 'Last name is required';
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      // Handle form submission logic
      alert('Form submitted successfully!');
    }
  };

  return (
    <section className="bg-gray-100 text-blue-900 py-16">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">Design Your Card</h2>
        <div className="flex flex-col lg:flex-row items-start">
          <div className="lg:w-1/2 lg:pr-8">
            <img
              src="img/company_card.jpg"
              alt="Design Preview"
              className="w-full h-auto rounded-lg shadow-md"
            />
          </div>
          <div className="lg:w-1/2 mt-8 lg:mt-0">
            <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-md">
              <div className="mb-4">
                <label htmlFor="cardType" className="block text-lg font-medium mb-2">Card Type</label>
                <select
                  id="cardType"
                  name="cardType"
                  value={formData.cardType}
                  onChange={handleChange}
                  className="block w-full p-2 border border-gray-300 rounded"
                >
                  <option value="classic">Classic</option>
                  <option value="company">Company</option>
                </select>
              </div>

              <div className="mb-4">
                <label htmlFor="color" className="block text-lg font-medium mb-2">Color</label>
                <input
                  type="color"
                  id="color"
                  name="color"
                  value={formData.color}
                  onChange={handleChange}
                  className="block w-full h-12 border-2 border-blue-500 rounded"
                />
              </div>

              <div className="mb-4">
                <label htmlFor="firstName" className="block text-lg font-medium mb-2">First Name</label>
                <input
                  type="text"
                  id="firstName"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  className="block w-full p-2 border border-gray-300 rounded"
                />
                {errors.firstName && <p className="text-red-500 text-sm mt-2">{errors.firstName}</p>}
              </div>

              <div className="mb-4">
                <label htmlFor="lastName" className="block text-lg font-medium mb-2">Last Name</label>
                <input
                  type="text"
                  id="lastName"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  className="block w-full p-2 border border-gray-300 rounded"
                />
                {errors.lastName && <p className="text-red-500 text-sm mt-2">{errors.lastName}</p>}
              </div>

              <div className="mb-4">
                <label htmlFor="role" className="block text-lg font-medium mb-2">Role</label>
                <input
                  type="text"
                  id="role"
                  name="role"
                  value={formData.role}
                  onChange={handleChange}
                  className="block w-full p-2 border border-gray-300 rounded"
                />
              </div>

              <div className="mb-4">
                <label htmlFor="companyName" className="block text-lg font-medium mb-2">Company Name (optional)</label>
                <input
                  type="text"
                  id="companyName"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleChange}
                  className="block w-full p-2 border border-gray-300 rounded"
                />
              </div>

              <div className="mb-4">
                <label htmlFor="contactNumber" className="block text-lg font-medium mb-2">Contact Number</label>
                <input
                  type="tel"
                  id="contactNumber"
                  name="contactNumber"
                  value={formData.contactNumber}
                  onChange={handleChange}
                  className="block w-full p-2 border border-gray-300 rounded"
                />
              </div>

              <button
                type="submit"
                className="bg-blue-700 text-white py-2 px-4 rounded hover:bg-blue-900 transition duration-300"
              >
                Buy Now
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Design;
