import React from 'react';

const Footer = () => {

  return (
    <footer className="bg-blue-900 text-white py-12">
      <div className="container mx-auto px-6 text-center">
   
        <div className="mb-6">
          <a href="#" className="text-3xl font-bold hover:text-gray-300">MYCARD</a>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
          <div>
            <h3 className="text-xl font-semibold mb-2">Home</h3>
            <p className="text-gray-400">Explore our main features and latest updates.</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">Services</h3>
            <p className="text-gray-400">Discover the range of services we offer to enhance your business.</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">About Us</h3>
            <p className="text-gray-400">Learn more about our mission, vision, and team.</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold mb-2">Contact</h3>
            <p className="text-gray-400">Get in touch with us for support or inquiries.</p>
          </div>
        </div>

        <div className="mb-6">
          <a href="#" className="hover:text-gray-300 mx-2">
            <i className="fab fa-facebook-f fa-lg"></i>
          </a>
          <a href="#" className="hover:text-gray-300 mx-2">
            <i className="fab fa-twitter fa-lg"></i>
          </a>
          <a href="#" className="hover:text-gray-300 mx-2">
            <i className="fab fa-linkedin-in fa-lg"></i>
          </a>
          <a href="#" className="hover:text-gray-300 mx-2">
            <i className="fab fa-instagram fa-lg"></i>
          </a>
        </div>
        
        <div className="mb-6">
          <p className="text-gray-400">1234 Street Name, City, State, 12345</p>
          <p className="text-gray-400">Email: <a href="mailto:contact@mycard.com" className="hover:text-gray-300">contact@mycard.com</a> | Phone: <a href="tel:+11234567890" className="hover:text-gray-300">(123) 456-7890</a></p>
        </div>

        <div className="text-gray-400">
          <p>© 2024 MYCARD. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
