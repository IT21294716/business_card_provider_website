import React from 'react';

const Herosection = () => {
  return (
    <section className="bg-blue-800 text-white py-20">
      <div className="container mx-auto px-6 text-center">
        <div className="flex flex-col md:flex-row items-center justify-center">
          <div className="md:w-1/2">
            <h1 className="text-5xl font-bold mb-4">Welcome to MYCARD</h1>
            <p className="text-xl mb-8">
              Your ultimate solution for creating and managing digital business cards with ease.
            </p>
            <a href="#" className="bg-white text-blue-900 py-2 px-6 rounded-full hover:bg-blue-700 hover:text-white transition duration-300">
              Get Started
            </a>
          </div>
          <div className="md:w-1/2 mt-8 md:mt-0">
            <img src="img/Hero-1.jpg" alt="Hero" className="w-full h-auto rounded-lg" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Herosection;
