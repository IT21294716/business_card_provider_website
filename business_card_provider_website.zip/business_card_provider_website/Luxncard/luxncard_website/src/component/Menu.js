import React from 'react';

const Menu = () => {
  return (
    <section className="bg-gray-100 text-blue-900 py-16">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="text-center bg-white p-6 rounded-lg shadow-md hover:bg-blue-700 hover:text-white transition duration-300">
            <h2 className="text-2xl font-bold mb-4">Digital Business Cards</h2>
            <p className="text-gray-800">
              Create, customize, and share digital business cards with ease. Perfect for professionals and businesses.
            </p>
          </div>
          <div className="text-center bg-white p-6 rounded-lg shadow-md hover:bg-blue-700 hover:text-white transition duration-300">
            <h2 className="text-2xl font-bold mb-4">Custom Designs</h2>
            <p className="text-gray-800">
              Choose from a variety of templates and designs to match your brand's identity and style.
            </p>
          </div>
          <div className="text-center bg-white p-6 rounded-lg shadow-md hover:bg-blue-700 hover:text-white transition duration-300">
            <h2 className="text-2xl font-bold mb-4">Secure Storage</h2>
            <p className="text-gray-800">
              Store all your contacts and card details securely in the cloud with our encrypted storage solutions.
            </p>
          </div>
          <div className="text-center bg-white p-6 rounded-lg shadow-md hover:bg-blue-700 hover:text-white transition duration-300">
            <h2 className="text-2xl font-bold mb-4">Analytics & Insights</h2>
            <p className="text-gray-800">
              Track how your business cards are being used and shared with our comprehensive analytics tools.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Menu;

