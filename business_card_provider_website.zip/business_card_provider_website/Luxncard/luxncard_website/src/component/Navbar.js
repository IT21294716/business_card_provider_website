import React, { useState } from 'react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-blue-900 text-white px-6 py-4 sticky top-0 z-50 shadow-md">
      <div className="container mx-auto flex items-center justify-between">
        <div className="text-2xl font-bold">
          <a href="#" className="hover:text-gray-300">MYCARD</a>
        </div>
        <div className="hidden md:flex space-x-6 items-center">
          <a href="#" className="hover:text-gray-300">Home</a>
          <a href="#" className="hover:text-gray-300">Services</a>
          <a href="#" className="hover:text-gray-300">About Us</a>
          <a href="#" className="hover:text-gray-300">Contact</a>
          <a href="#" className="bg-white text-blue-900 py-2 px-4 rounded hover:bg-blue-700 hover:text-white transition duration-300">
            Profile
          </a>
        </div>
        <div className="md:hidden">
          <button 
            onClick={() => setIsOpen(!isOpen)} 
            className="text-white focus:outline-none"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16m-7 6h7"}></path>
            </svg>
          </button>
        </div>
      </div>
      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden">
          <a href="#" className="block px-4 py-2 text-sm hover:bg-blue-700">Home</a>
          <a href="#" className="block px-4 py-2 text-sm hover:bg-blue-700">Services</a>
          <a href="#" className="block px-4 py-2 text-sm hover:bg-blue-700">About Us</a>
          <a href="#" className="block px-4 py-2 text-sm hover:bg-blue-700">Contact</a>
          <a href="#" className="block px-4 py-2 text-sm bg-white text-blue-900 rounded hover:bg-blue-700 hover:text-white transition duration-300">
            Profile
          </a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
