import React from 'react';

const Products = () => {
  return (
    <section className="bg-gray-100 text-blue-900 py-16">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl font-bold text-center mb-12">Buy Products</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Classic White Card */}
          <div className="text-center bg-white p-6 rounded-lg shadow-md hover:bg-blue-700 hover:text-white transition duration-300">
            <h3 className="text-xl font-bold mb-4">Classic White Card</h3>
            <img src="img/white_card.jpg" alt="Classic White Card" className="h-40 w-full object-cover mb-4"/>
            <p className="text-gray-800 text-lg font-medium mb-4">LKR 1999</p>
            <button className="bg-blue-700 text-white py-2 px-4 rounded hover:bg-blue-900 transition duration-300">
              Buy Now
            </button>
          </div>

          {/* Classic Black Card */}
          <div className="text-center bg-white p-6 rounded-lg shadow-md hover:bg-blue-700 hover:text-white transition duration-300">
            <h3 className="text-xl font-bold mb-4">Classic Black Card</h3>
            <img src="img/black_card.jpg" alt="Classic Black Card" className="h-40 w-full object-cover mb-4"/>
            <p className="text-gray-800 text-lg font-medium mb-4">LKR 2199</p>
            <button className="bg-blue-700 text-white py-2 px-4 rounded hover:bg-blue-900 transition duration-300">
              Buy Now
            </button>
          </div>

          {/* Classic Color Card */}
          <div className="text-center bg-white p-6 rounded-lg shadow-md hover:bg-blue-700 hover:text-white transition duration-300">
            <h3 className="text-xl font-bold mb-4">Classic Color Card</h3>
            <img src="img/colour_card.jpg" alt="Classic Color Card" className="h-40 w-full object-cover mb-4"/>
            <p className="text-gray-800 text-lg font-medium mb-4">LKR 2299</p>
            <button className="bg-blue-700 text-white py-2 px-4 rounded hover:bg-blue-900 transition duration-300">
              Buy Now
            </button>
          </div>

          {/* Company Card */}
          <div className="text-center bg-white p-6 rounded-lg shadow-md hover:bg-blue-700 hover:text-white transition duration-300">
            <h3 className="text-xl font-bold mb-4">Company Card</h3>
            <img src="img/company_card.jpg" alt="Company Card" className="h-40 w-full object-cover mb-4"/>
            <p className="text-gray-800 text-lg font-medium mb-4">LKR 2499</p>
            <button className="bg-blue-700 text-white py-2 px-4 rounded hover:bg-blue-900 transition duration-300">
              Buy Now
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Products;
