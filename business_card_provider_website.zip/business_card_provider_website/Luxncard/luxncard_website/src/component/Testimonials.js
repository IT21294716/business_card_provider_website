import React from 'react';

const Testimonials = () => {
  const testimonials = [
    {
      name: "John Doe",
      image: "img/customer_1.jpg",
      feedback: "MYCARD has revolutionized the way I share my business cards. The designs are sleek, and the service is excellent!"
    },
    {
      name: "Jane Smith",
      image: "img/customer_2.jpg",
      feedback: "The custom designs offered by MYCARD perfectly matched my brand identity. Highly recommend their service!"
    },
    {
      name: "Michael Johnson",
      image: "img/customer_3.jpg",
      feedback: "The digital cards are a game-changer. The process is so easy and convenient, and the analytics are insightful."
    }
  ];

  return (
    <section className="bg-white text-blue-900 py-16">
      <div className="container mx-auto px-6 text-center">
        <h2 className="text-3xl font-bold mb-12">Customer Testimonials</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-gray-100 p-6 rounded-lg shadow-md">
              <img 
                src={testimonial.image} 
                alt={testimonial.name} 
                className="h-24 w-24 rounded-full mx-auto mb-4"
              />
              <h3 className="text-xl font-bold mb-2">{testimonial.name}</h3>
              <p className="text-gray-700">{testimonial.feedback}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
